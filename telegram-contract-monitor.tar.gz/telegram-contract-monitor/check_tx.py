#!/usr/bin/env python3
"""
Скрипт для проверки событий в конкретной транзакции
"""

import sys
from web3 import Web3
import json

# Конфигурация
CONTRACT_ADDRESS = '0x614917a75A00f757aa5EDADB5a92675Af587085E'
CORE_CHAIN_RPC = 'https://rpc.coredao.org'

# Ваша транзакция
TX_HASH = '0xcf6325b09b6ca51fb7b8904f8fb961c3eb0b790e75885675ea6f463626b186ce'

def check_transaction():
    """Проверить события в транзакции"""
    
    # Подключение к Core Chain
    w3 = Web3(Web3.HTTPProvider(CORE_CHAIN_RPC))
    
    if not w3.is_connected():
        print("❌ Не удалось подключиться к Core Chain")
        return
    
    print(f"✅ Подключено к Core Chain (Chain ID: {w3.eth.chain_id})")
    print(f"\n🔍 Проверяем транзакцию: {TX_HASH}")
    print("=" * 80)
    
    try:
        # Получаем receipt транзакции
        receipt = w3.eth.get_transaction_receipt(TX_HASH)
        
        print(f"\n📦 Блок: {receipt['blockNumber']}")
        print(f"✅ Статус: {'Success' if receipt['status'] == 1 else 'Failed'}")
        print(f"⛽ Gas использовано: {receipt['gasUsed']}")
        print(f"\n📋 Всего событий (logs): {len(receipt['logs'])}")
        print("=" * 80)
        
        # Проверяем каждый лог
        for i, log in enumerate(receipt['logs']):
            print(f"\n--- Событие #{i + 1} ---")
            print(f"Контракт: {log['address']}")
            print(f"Topics ({len(log['topics'])}):")
            
            for j, topic in enumerate(log['topics']):
                topic_hex = topic.hex()
                print(f"  Topic {j}: {topic_hex}")
                
                # Пытаемся определить событие по сигнатуре
                if j == 0:  # Первый topic - это event signature
                    # Известные сигнатуры событий Aave/Compound
                    known_signatures = {
                        w3.keccak(text="Repay(address,address,address,uint256)").hex(): "Repay(address,address,address,uint256)",
                        w3.keccak(text="LiquidationCall(address,address,address,uint256,uint256,address,bool)").hex(): "LiquidationCall(address,address,address,uint256,uint256,address,bool)",
                        w3.keccak(text="Borrow(address,address,address,uint256,uint256,uint256,uint16)").hex(): "Borrow",
                        w3.keccak(text="Supply(address,address,address,uint256,uint16)").hex(): "Supply",
                        w3.keccak(text="Withdraw(address,address,address,uint256)").hex(): "Withdraw",
                        w3.keccak(text="Transfer(address,address,uint256)").hex(): "Transfer",
                        w3.keccak(text="Approval(address,address,uint256)").hex(): "Approval",
                    }
                    
                    if topic_hex in known_signatures:
                        print(f"  ✅ Распознано: {known_signatures[topic_hex]}")
            
            print(f"Data: {log['data'][:66]}..." if len(log['data']) > 66 else f"Data: {log['data']}")
            
            # Проверяем, от нашего ли контракта это событие
            if log['address'].lower() == CONTRACT_ADDRESS.lower():
                print("  🎯 ЭТО СОБЫТИЕ ОТ ЦЕЛЕВОГО КОНТРАКТА!")
        
        print("\n" + "=" * 80)
        print("✅ Анализ завершен!")
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        TX_HASH = sys.argv[1]
    
    check_transaction()
