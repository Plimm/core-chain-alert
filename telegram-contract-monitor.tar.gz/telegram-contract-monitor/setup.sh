#!/bin/bash

echo "================================"
echo "Установка Contract Monitor Bot"
echo "================================"
echo ""

# Проверка Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 не найден. Установите Python 3.8 или выше."
    exit 1
fi

echo "✅ Python найден: $(python3 --version)"

# Проверка pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip не найден. Установите pip."
    exit 1
fi

echo "✅ pip найден"
echo ""

# Установка зависимостей
echo "📦 Установка зависимостей..."
pip3 install -r requirements.txt --break-system-packages || pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ Зависимости установлены"
else
    echo "❌ Ошибка установки зависимостей"
    exit 1
fi

echo ""

# Создание .env файла
if [ ! -f .env ]; then
    echo "📝 Создание .env файла..."
    cp .env.example .env
    echo "✅ Файл .env создан"
    echo ""
    echo "⚠️  ВАЖНО: Отредактируйте файл .env и добавьте:"
    echo "   - TELEGRAM_BOT_TOKEN (получите у @BotFather)"
    echo "   - TELEGRAM_CHAT_ID (получите у @userinfobot)"
    echo ""
    echo "Команда для редактирования: nano .env"
else
    echo "ℹ️  Файл .env уже существует"
fi

echo ""
echo "================================"
echo "Установка завершена!"
echo "================================"
echo ""
echo "Следующие шаги:"
echo "1. Создайте бота через @BotFather в Telegram"
echo "2. Получите Chat ID через @userinfobot"
echo "3. Отредактируйте .env файл: nano .env"
echo "4. Запустите бота:"
echo "   export \$(cat .env | xargs) && python3 bot.py"
echo ""
