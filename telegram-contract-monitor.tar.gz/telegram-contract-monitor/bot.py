#!/usr/bin/env python3
"""
Telegram бот для мониторинга событий LiquidationCall и Repay
на смарт-контракте в сети Core Chain
"""

import asyncio
import logging
from web3 import Web3
from web3.exceptions import BlockNotFound
import json
from telegram import Bot
from telegram.error import TelegramError
import os
from datetime import datetime

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Конфигурация
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', 'YOUR_CHAT_ID_HERE')
CONTRACT_ADDRESS = '0x614917a75A00f757aa5EDADB5a92675Af587085E'

# Core Chain RPC endpoints
CORE_CHAIN_RPC = [
    'https://rpc.coredao.org',
    'https://rpc-core.icecreamswap.com',
]

# ABI для событий LiquidationCall и Repay (стандартные события Aave/Compound-подобных протоколов)
CONTRACT_ABI = json.dumps([
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "collateralAsset", "type": "address"},
            {"indexed": True, "name": "debtAsset", "type": "address"},
            {"indexed": True, "name": "user", "type": "address"},
            {"indexed": False, "name": "debtToCover", "type": "uint256"},
            {"indexed": False, "name": "liquidatedCollateralAmount", "type": "uint256"},
            {"indexed": False, "name": "liquidator", "type": "address"},
            {"indexed": False, "name": "receiveAToken", "type": "bool"}
        ],
        "name": "LiquidationCall",
        "type": "event"
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "reserve", "type": "address"},
            {"indexed": True, "name": "user", "type": "address"},
            {"indexed": True, "name": "repayer", "type": "address"},
            {"indexed": False, "name": "amount", "type": "uint256"}
        ],
        "name": "Repay",
        "type": "event"
    }
])


class ContractMonitor:
    def __init__(self):
        self.w3 = None
        self.contract = None
        self.bot = None
        self.last_block = None
        self.setup_connection()
        
    def setup_connection(self):
        """Установка соединения с Core Chain"""
        for rpc_url in CORE_CHAIN_RPC:
            try:
                self.w3 = Web3(Web3.HTTPProvider(rpc_url))
                if self.w3.is_connected():
                    logger.info(f"Подключено к Core Chain через {rpc_url}")
                    logger.info(f"Chain ID: {self.w3.eth.chain_id}")
                    break
            except Exception as e:
                logger.warning(f"Не удалось подключиться к {rpc_url}: {e}")
                continue
        
        if not self.w3 or not self.w3.is_connected():
            raise Exception("Не удалось подключиться ни к одному RPC узлу Core Chain")
        
        # Настройка контракта
        self.contract = self.w3.eth.contract(
            address=Web3.to_checksum_address(CONTRACT_ADDRESS),
            abi=json.loads(CONTRACT_ABI)
        )
        
        # Настройка Telegram бота
        self.bot = Bot(token=TELEGRAM_BOT_TOKEN)
        
        # Получаем текущий блок
        self.last_block = self.w3.eth.block_number
        logger.info(f"Начинаем мониторинг с блока {self.last_block}")
    
    async def send_telegram_message(self, message):
        """Отправка сообщения в Telegram"""
        try:
            await self.bot.send_message(
                chat_id=TELEGRAM_CHAT_ID,
                text=message,
                parse_mode='HTML'
            )
            logger.info(f"Уведомление отправлено: {message[:50]}...")
        except TelegramError as e:
            logger.error(f"Ошибка отправки в Telegram: {e}")
    
    def format_liquidation_event(self, event):
        """Форматирование события LiquidationCall"""
        args = event['args']
        tx_hash = event['transactionHash'].hex()
        block = event['blockNumber']
        
        message = f"""
🚨 <b>LIQUIDATION DETECTED!</b> 🚨

📍 <b>Контракт:</b> <code>{CONTRACT_ADDRESS}</code>
🔗 <b>TX Hash:</b> <code>{tx_hash}</code>
📦 <b>Блок:</b> {block}

👤 <b>Ликвидируемый:</b> <code>{args['user']}</code>
⚡ <b>Ликвидатор:</b> <code>{args['liquidator']}</code>

💰 <b>Collateral Asset:</b> <code>{args['collateralAsset']}</code>
💸 <b>Debt Asset:</b> <code>{args['debtAsset']}</code>

📊 <b>Долг к покрытию:</b> {Web3.from_wei(args['debtToCover'], 'ether')} tokens
💎 <b>Ликвидированный коллатерал:</b> {Web3.from_wei(args['liquidatedCollateralAmount'], 'ether')} tokens

🔍 Explorer: https://scan.coredao.org/tx/{tx_hash}
"""
        return message
    
    def format_repay_event(self, event):
        """Форматирование события Repay"""
        args = event['args']
        tx_hash = event['transactionHash'].hex()
        block = event['blockNumber']
        
        message = f"""
✅ <b>REPAY DETECTED!</b> ✅

📍 <b>Контракт:</b> <code>{CONTRACT_ADDRESS}</code>
🔗 <b>TX Hash:</b> <code>{tx_hash}</code>
📦 <b>Блок:</b> {block}

👤 <b>Пользователь:</b> <code>{args['user']}</code>
💳 <b>Плательщик:</b> <code>{args['repayer']}</code>

💰 <b>Reserve:</b> <code>{args['reserve']}</code>
📊 <b>Сумма погашения:</b> {Web3.from_wei(args['amount'], 'ether')} tokens

🔍 Explorer: https://scan.coredao.org/tx/{tx_hash}
"""
        return message
    
    async def check_events(self):
        """Проверка новых событий"""
        try:
            current_block = self.w3.eth.block_number
            
            if current_block <= self.last_block:
                return
            
            logger.info(f"Проверяем блоки с {self.last_block + 1} по {current_block}")
            
            # Получаем ВСЕ логи от контракта (альтернативный подход)
            try:
                all_logs = self.w3.eth.get_logs({
                    'fromBlock': self.last_block + 1,
                    'toBlock': current_block,
                    'address': Web3.to_checksum_address(CONTRACT_ADDRESS)
                })
                
                logger.info(f"Найдено {len(all_logs)} событий от контракта")
                
                for log in all_logs:
                    try:
                        # Пробуем распарсить как LiquidationCall
                        event = self.contract.events.LiquidationCall().process_log(log)
                        message = self.format_liquidation_event(event)
                        await self.send_telegram_message(message)
                        logger.info(f"✅ Обнаружена ликвидация в блоке {event['blockNumber']}")
                        continue
                    except:
                        pass
                    
                    try:
                        # Пробуем распарсить как Repay
                        event = self.contract.events.Repay().process_log(log)
                        message = self.format_repay_event(event)
                        await self.send_telegram_message(message)
                        logger.info(f"✅ Обнаружено погашение в блоке {event['blockNumber']}")
                        continue
                    except:
                        pass
                    
                    # Если не смогли распарсить - выводим информацию о событии
                    logger.debug(f"Неизвестное событие: topics={[t.hex() for t in log['topics']]}")
                        
            except Exception as e:
                logger.error(f"Ошибка при получении событий: {e}")
            
            self.last_block = current_block
            
        except Exception as e:
            logger.error(f"Ошибка при проверке событий: {e}")
    
    async def run(self):
        """Основной цикл мониторинга"""
        logger.info("Бот запущен и начинает мониторинг...")
        
        # Отправляем стартовое сообщение
        start_message = f"""
🤖 <b>Бот мониторинга запущен!</b>

📍 Контракт: <code>{CONTRACT_ADDRESS}</code>
🌐 Сеть: Core Chain
📊 События: LiquidationCall, Repay
🕐 Время запуска: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        await self.send_telegram_message(start_message)
        
        while True:
            try:
                await self.check_events()
                await asyncio.sleep(5)  # Проверяем каждые 5 секунд
            except KeyboardInterrupt:
                logger.info("Остановка бота...")
                break
            except Exception as e:
                logger.error(f"Ошибка в основном цикле: {e}")
                await asyncio.sleep(10)


async def main():
    """Точка входа"""
    try:
        monitor = ContractMonitor()
        await monitor.run()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
