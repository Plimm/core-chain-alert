#!/usr/bin/env python3
"""
Скрипт для получения ABI контракта из Core Chain explorer API
"""

import requests
import json

CONTRACT_ADDRESS = '0x614917a75A00f757aa5EDADB5a92675Af587085E'

def get_contract_abi():
    """Получить ABI контракта из Core Chain explorer"""
    
    # Core Chain explorer API
    explorer_api = 'https://openapi.coredao.org/api'
    
    params = {
        'module': 'contract',
        'action': 'getabi',
        'address': CONTRACT_ADDRESS,
    }
    
    try:
        response = requests.get(explorer_api, params=params)
        data = response.json()
        
        if data['status'] == '1':
            abi = json.loads(data['result'])
            
            # Ищем события LiquidationCall и Repay
            events = [item for item in abi if item.get('type') == 'event']
            
            print("Найденные события в контракте:")
            print("-" * 50)
            
            for event in events:
                print(f"\nСобытие: {event['name']}")
                print("Параметры:")
                for input_param in event.get('inputs', []):
                    indexed = " (indexed)" if input_param.get('indexed') else ""
                    print(f"  - {input_param['name']}: {input_param['type']}{indexed}")
            
            # Сохраняем полный ABI
            with open('contract_abi.json', 'w') as f:
                json.dump(abi, f, indent=2)
            
            print("\n" + "=" * 50)
            print("Полный ABI сохранен в contract_abi.json")
            
            return abi
        else:
            print(f"Ошибка получения ABI: {data.get('message', 'Unknown error')}")
            print("\nИспользуйте стандартный ABI из bot.py")
            return None
            
    except Exception as e:
        print(f"Ошибка: {e}")
        print("\nНе удалось получить ABI из explorer.")
        print("Используйте стандартный ABI из bot.py или укажите ABI вручную.")
        return None


if __name__ == "__main__":
    print(f"Получение ABI для контракта: {CONTRACT_ADDRESS}")
    print("=" * 50)
    get_contract_abi()
