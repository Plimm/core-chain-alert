# Telegram Бот Мониторинга Смарт-Контракта

Этот бот отслеживает события `LiquidationCall` и `Repay` на смарт-контракте в сети Core Chain и отправляет уведомления в Telegram.

## 📋 Возможности

- ✅ Мониторинг событий LiquidationCall (ликвидации)
- ✅ Мониторинг событий Repay (погашение долга)
- ✅ Отправка детальных уведомлений в Telegram
- ✅ Автоматическое переподключение при сбоях
- ✅ Поддержка нескольких RPC узлов

## 🎯 Отслеживаемый контракт

- **Адрес:** `0x614917a75A00f757aa5EDADB5a92675Af587085E`
- **Сеть:** Core Chain
- **События:** LiquidationCall, Repay

## 🚀 Быстрый старт

### 1. Создание Telegram бота

1. Откройте Telegram и найдите [@BotFather](https://t.me/BotFather)
2. Отправьте команду `/newbot`
3. Следуйте инструкциям и придумайте имя для бота
4. Сохраните токен, который даст вам BotFather (формат: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

### 2. Получение Chat ID

1. Найдите вашего бота в Telegram и отправьте ему любое сообщение
2. Используйте [@userinfobot](https://t.me/userinfobot) или [@getidsbot](https://t.me/getidsbot) чтобы получить ваш Chat ID
3. Или откройте в браузере: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
4. Найдите `"chat":{"id":123456789}` - это ваш Chat ID

### 3. Установка зависимостей

```bash
# Установите Python 3.8 или выше
python3 --version

# Установите pip зависимости
pip install -r requirements.txt --break-system-packages
```

### 4. Настройка

Создайте файл `.env` на основе `.env.example`:

```bash
cp .env.example .env
nano .env  # или используйте любой текстовый редактор
```

Заполните файл `.env`:

```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_CHAT_ID=123456789
```

### 5. Запуск бота

```bash
# Если используете .env файл
export $(cat .env | xargs) && python3 bot.py

# Или напрямую с переменными окружения
TELEGRAM_BOT_TOKEN=your_token TELEGRAM_CHAT_ID=your_chat_id python3 bot.py
```

## 📊 Пример уведомлений

### LiquidationCall

```
🚨 LIQUIDATION DETECTED! 🚨

📍 Контракт: 0x614917a75A00f757aa5EDADB5a92675Af587085E
🔗 TX Hash: 0xabcd...
📦 Блок: 12345678

👤 Ликвидируемый: 0x1234...
⚡ Ликвидатор: 0x5678...

💰 Collateral Asset: 0xabcd...
💸 Debt Asset: 0xefgh...

📊 Долг к покрытию: 1000.0 tokens
💎 Ликвидированный коллатерал: 1200.0 tokens

🔍 Explorer: https://scan.coredao.org/tx/0xabcd...
```

### Repay

```
✅ REPAY DETECTED! ✅

📍 Контракт: 0x614917a75A00f757aa5EDADB5a92675Af587085E
🔗 TX Hash: 0xabcd...
📦 Блок: 12345678

👤 Пользователь: 0x1234...
💳 Плательщик: 0x5678...

💰 Reserve: 0xabcd...
📊 Сумма погашения: 500.0 tokens

🔍 Explorer: https://scan.coredao.org/tx/0xabcd...
```

## 🔧 Запуск в фоновом режиме

### Используя screen

```bash
screen -S contract-monitor
python3 bot.py
# Нажмите Ctrl+A затем D чтобы отключиться
# screen -r contract-monitor чтобы вернуться
```

### Используя systemd (Linux)

Создайте файл `/etc/systemd/system/contract-monitor.service`:

```ini
[Unit]
Description=Contract Monitor Telegram Bot
After=network.target

[Service]
Type=simple
User=your_username
WorkingDirectory=/path/to/telegram-contract-monitor
Environment="TELEGRAM_BOT_TOKEN=your_token"
Environment="TELEGRAM_CHAT_ID=your_chat_id"
ExecStart=/usr/bin/python3 /path/to/telegram-contract-monitor/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Запустите сервис:

```bash
sudo systemctl daemon-reload
sudo systemctl enable contract-monitor
sudo systemctl start contract-monitor
sudo systemctl status contract-monitor
```

## 🛠️ Настройка

### Изменение частоты проверки

В файле `bot.py` найдите строку:

```python
await asyncio.sleep(5)  # Проверяем каждые 5 секунд
```

Измените значение на нужное (в секундах).

### Изменение RPC узлов

В файле `bot.py` измените список `CORE_CHAIN_RPC`:

```python
CORE_CHAIN_RPC = [
    'https://rpc.coredao.org',
    'https://rpc-core.icecreamswap.com',
    'https://your-custom-rpc.com',
]
```

## 📝 Логи

Бот выводит логи в консоль:

```
2024-01-15 10:30:00 - __main__ - INFO - Подключено к Core Chain через https://rpc.coredao.org
2024-01-15 10:30:00 - __main__ - INFO - Chain ID: 1116
2024-01-15 10:30:00 - __main__ - INFO - Начинаем мониторинг с блока 12345678
2024-01-15 10:30:00 - __main__ - INFO - Бот запущен и начинает мониторинг...
```

## ⚠️ Важные замечания

1. **ABI контракта**: Бот использует стандартный ABI для событий Aave/Compound-подобных протоколов. Если ваш контракт имеет другую сигнатуру событий, вам нужно будет обновить `CONTRACT_ABI` в коде.

2. **RPC лимиты**: Некоторые публичные RPC узлы имеют ограничения на количество запросов. Если получаете ошибки, используйте собственный RPC узел или увеличьте интервал проверки.

3. **Пропущенные блоки**: Если бот был выключен, он начнет мониторинг с текущего блока, а не с того момента, когда был остановлен.

## 🐛 Решение проблем

### Бот не подключается к Core Chain

- Проверьте доступность RPC узлов
- Попробуйте другие RPC endpoints
- Проверьте интернет-соединение

### Уведомления не приходят

- Убедитесь, что токен бота правильный
- Проверьте Chat ID
- Убедитесь, что вы написали боту хотя бы одно сообщение

### События не обнаруживаются

- Убедитесь, что ABI соответствует контракту
- Проверьте адрес контракта
- Проверьте логи на наличие ошибок

## 📄 Лицензия

MIT License

## 🤝 Поддержка

Если у вас возникли вопросы или проблемы, создайте issue или свяжитесь со мной.
